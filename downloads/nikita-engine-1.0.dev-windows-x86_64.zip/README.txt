Nikita Engine 1.0.dev - Windows x86_64

Run Nikita.exe. There is nothing to install and no account to create.

To export a game you need the export templates. The editor can fetch them for
you: Editor > Manage Export Templates > Download and Install.

Nikita.console.exe is the same editor with a console attached, for when you
want to watch engine output on Windows.

Documentation:
  https://nikita12332112d.github.io/nikita-engine-site/docs.html

The licenses folder carries the notices for third-party code included in this
engine, and they must stay with any copy you pass on. The same text is built
into the editor as well, under Help > About > Third-party Licenses.
